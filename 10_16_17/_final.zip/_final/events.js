// When scrolling down so the top of the viewport is at or below the top of the element with the id navActivator,
// the element with the id mainNav (navigation bar) will be added to the displayNav class and removed from the hiddenNav class.
// When scrolling back up so that the top of the element with the id navActivator appears below the top of the viewport,
// the element with the id mainNav will be added to the hiddenNav class and removed from the displayNav class

function toggleToTop () {
    var navBar = document.getElementById("navToTop");
    if (document.getElementById("triggerToTop").getBoundingClientRect().top < 0) {
        navBar.classList.remove("hideToTop");
        navBar.classList.add("showToTop");
    } else {
        navBar.classList.remove("showToTop");
        navBar.classList.add("hideToTop");
    }
}

document.addEventListener("DOMContentLoaded", toggleToTop);
document.addEventListener("load", toggleToTop);
document.addEventListener("scroll", toggleToTop);
document.addEventListener("resize", toggleToTop);
